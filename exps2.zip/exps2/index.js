var http = require("http");
var mongoose= require("mongoose");

//var {requestHandler} = require ("./requesthandler");

//  var server= http.createServer(requestHandler);

const app = require("./server");

mongoose.connect("mongodb://127.0.0.1:27107/shopdb",{useNewUrlParser:true})
;var server= http.createServer(app);
   


 server.listen(6100,(err)=>
 {
     if(err)
     {
            console.log("coulnot start");
            return;
     }
     console.log("sevr started at port xxxx");
 })

 