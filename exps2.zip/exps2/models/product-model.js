
var mongoose = require("mongoose");
var ProductSchema = mongoose.Schema({
    Id: { type: Number, required: true },
    Name: { type: String, required: true },
    Price: { type: Number, required: true },
    Quantity: { type: Number,  required: true }
});
module.exports = mongoose.model("product", ProductSchema);
