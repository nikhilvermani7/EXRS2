const express = require("express");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const Session = require("express-session");
const path= require("path");
const commonRoutes= require("./routes/common-routes");
const productsRoutes= require("./routes/products-routes");



//create express app object

var app = express();

//ste the view engine
app.set("views","views");
app.set("view engine", "pug");

app.use(express.static(path.resolve(__dirname,"public")));


app.use(cookieParser("mysecretkey"));
app.use(Session({name:"session1",
                 resave:true, 
                 saveUninitialized:false,
                 secret:"mysecretsessionkey"}));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended:true}));

                 //configure routes


app.use("/", commonRoutes);
app.use("/products", productsRoutes);



module.exports = app;

