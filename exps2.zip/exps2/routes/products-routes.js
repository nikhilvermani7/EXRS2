const express = require("express");
const User= require("../models/user-model");
const bcrypt = require("bcryptjs");
var Product = require("../models/product-model");
var router = express.Router();




// var products = [
//     { id: 1, name: "apple", quantity: 10, price: 20 },
//     { id: 2, name: "mango", quantity: 10, price: 30 },
//     { id: 3, name: "orangeeeeee", quantity: 10, price: 40 },
//     { id: 4, name: "blueberry", quantity: 10, price: 60 },
// ]

router.get("/", (req, res) => {
    res.header("content-type", "text/html").send("products");
})

// router.get("/lists", (req, res) => {
//     var model = {
//         caption: "products-lists",
//         items: products
//     };
//     res.header("content-type", "text/html").render("products-lists", model);
// })
router.get("/lists", (req, res) => {
    var model = {
        caption: "products-lists",
        
    };
    Product.find((err,result)=>
    {
        if (err)
        {
            model.items= undefined;
        }
        else{
            model.items= result;

        }
        res.header("content-type", "text/html").render("products-lists", model);
    });
  
});



router.get("/add", (req, res) => {
    res.header("content-type", "text/html").render("add");
}) 

router.post("/add", (req, res) => {
    // var formData= req.body;
    // console.log(formData);
    // res.send(formData);
    var formData= req.body;
    var salt= bcrypt.genSaltSync(15);
    var user= new User({
        firstName:formData.name,
        email:formData.email,
        password: bcrypt.hashSync(formData.password,salt)
       });
       console.log(bcrypt.compareSync(formData.password,user.password))
       user.save(function(err){
           if(err)
           {
               res.send("error in svaing");
           }
           res.send("success");
       })
    
})



module.exports = router;