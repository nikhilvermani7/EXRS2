const express =require("express");
   var router= express.Router();

   router.get("/",(req,res)=>{
    //    res.header("content-type","text/html").send("home");
    res.header("content-type","text/html").render("index");
   })

   
   router.get("/about",(req,res)=>{
    res.header("content-type","text/html").render("about");
})


router.get("/contact",(req,res)=>{
    res.header("content-type","text/html").render("contact");
})




module.exports=router;